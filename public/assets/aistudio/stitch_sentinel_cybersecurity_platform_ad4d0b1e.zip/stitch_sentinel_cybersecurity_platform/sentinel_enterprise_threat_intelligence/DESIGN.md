---
name: Sentinel Enterprise Threat Intelligence
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#444651'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#002d48'
  on-tertiary: '#ffffff'
  tertiary-container: '#004469'
  on-tertiary-container: '#56b3f9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '600'
    lineHeight: 1.375rem
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-md:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
  mono-lg:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
    letterSpacing: -0.01em
  mono-md:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
    letterSpacing: 0em
  mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '400'
    lineHeight: 1rem
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.025em
  label-sm:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.375rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system is engineered for security operations center (SOC) operators, tier-3 incident responders, fraud examiners, and threat hunting teams who navigate massive volumes of telemetry under mission-critical conditions. 

### Brand Personality & Emotional Posture
- **Authoritative & Mission-Focused:** Instills unshakeable operational control. Visual noise is minimized to reduce cognitive fatigue during multi-hour investigations and critical incident declarations.
- **Surgical Precision:** Every border, line of telemetry, and metadata tag is deliberate, structural, and alignment-locked. 
- **Utilitarian Elegance:** Rejects cinematic "cyberpunk" neon tropes, faux radar pulses, and gratuitous glow shaders. It prioritizes information velocity, scan speed, and high-density legibility modeled after Tier-1 defense networks and institutional observability consoles.

### Design Movement: Precision Enterprise Minimalist
The aesthetic integrates structured Swiss information architecture with high-density enterprise ergonomics:
- **Light-First Architecture:** Delivers high visual acuity during daylight shift rotations and command-center triage. High contrast ratios prevent visual distortion during rapid optical scanning across multi-monitor arrays.
- **Micro-Layered Information Architecture:** Structural 1px hairline borders segment analytical domains rather than heavy blurred drop shadows or soft gradients.
- **Strict Visual Hierarchy:** Chromatic saturation is strictly reserved for actionable threat intelligence, triage severity levels, operational status triggers, and critical user interaction surfaces.

## Colors

The system uses a strictly regulated color distribution model. Color functions strictly as semantic status, active focus, or hierarchical anchoring—never purely decorative.

### Core Canvas & Structure
- **App Canvas (`#F8FAFC`):** Low-strain, cool structural background providing separation from elevated white content containers.
- **Surface Elevation (`#FFFFFF`):** High-clarity foreground panels, analytical cards, data tables, and slide-over inspector drawers.
- **Surface Muted / Inset (`#F1F5F9`):** Sub-tables, code blocks, secondary filter rails, and table header rows.
- **Structural Hairlines (`#E2E8F0`):** Crisp 1px division borders, cell separators, and container edges.
- **Structural Hairlines Active (`#CBD5E1`):** Subtly prominent borders for focused cards, interactive table rows, and hover targets.

### Text & Neutral Hierarchy
- **Text Primary (`#0F172A`):** Deep enterprise slate delivering WCAG AAA-compliant optical contrast for telemetry reading.
- **Text Secondary (`#475569`):** Metadata keys, contextual descriptions, muted field tags.
- **Text Tertiary / Disabled (`#94A3B8`):** Inactive indicators, table pagination counts, placeholder labels.

### Brand & Interactive Accent
- **Primary Navy (`#1E3A8A`):** Structural authority tone for global navigation headers, primary execution triggers, and modal confirmation states.
- **Interactive Cobalt (`#2563EB`):** High-visibility indicator for focused filters, text links, active graph nodes, and primary active inputs.
- **Interactive Cobalt Subtle (`#EFF6FF`):** Selected row states, active multi-select chips, and tab hover backgrounds.

### Threat Severity & Triage Telemetry Spectrum
Severity tokens must strictly follow standardized incident response taxonomies:
- **Critical (`#DC2626` | Tint: `#FEF2F2` | Border: `#FCA5A5`):** Confirmed active breach, C2 beacons, automated lateral movement, zero-day exploitation.
- **High (`#EA580C` | Tint: `#FFF7ED` | Border: `#FDBA74`):** Privilege escalation, credential dumping, exfiltration activity.
- **Medium (`#D97706` | Tint: `#FFFBEB` | Border: `#FCD34D`):** Policy violations, atypical geographic authentication, evasive scripting.
- **Low (`#059669` | Tint: `#ECFDF5` | Border: `#A7F3D0`):** Reconnaissance sweeps, outdated package versions, unverified port scans.
- **Informational (`#0284C7` | Tint: `#F0F9FF` | Border: `#BAE6FD`):** Configuration alterations, standard daemon restarts, non-impact audit trails.
- **Benign / Verified Safe (`#10B981` | Tint: `#F0FDF4` | Border: `#BBF7D0`):** Cleared entities, verified allowlist domains, validated human actions.

## Typography

The typography architecture uses a dual-engine font stack optimized for dense multi-pane interfaces:

1. **System Primary (`Inter`):** Governs structure, UI controls, navigation labels, contextual body text, and operational summaries. Inter is selected for its high x-height, neutral letterforms, and legibility at sub-pixel sizes (11px–13px).
2. **Telemetry Monospace (`JetBrains Mono`):** Applied exclusively to Indicators of Compromise (IoCs): IPv4/IPv6 strings, SHA256/MD5 hashes, autonomous system numbers (ASNs), domain names, UTC timestamps, SIEM query syntax, and regex patterns. Monospace tokens maintain tabular numeral alignment across dense vertically stacked logs.

### Application Rules
- **Tabular Figures:** All numeric fields inside data grids, metric cards, and charts must enforce `font-variant-numeric: tabular-nums` to eliminate layout jitter during live-streamed socket updates.
- **Micro-Labels:** All table column headers, status badge tags, and input categorization captions utilize `label-sm` with explicit uppercase transformation (`text-transform: uppercase`) and widened tracking for optical scanning.
- **Punctuation Truncation:** Telemetry strings (hashes, file paths) exceeding container bounds must apply middle-truncation (`truncate-middle`) or monospace ellipsis to preserve critical prefix and checksum suffix values.

## Layout & Spacing

The layout model optimizes space utilization for multi-monitor operation (1920x1080 up to 4K displays), eliminating dead whitespace while maintaining strict visual grouping.

### The 4px Base Metric Unit
All dimensions, paddings, gutters, and layout boundaries are multiples of 4px. Structural grid elements default to a baseline density of 12px (`space-md`) and 16px (`space-lg`), rather than the expansive 24px–32px spacings common in consumer software.

### Canvas Grid Model
- **Master Layout Structure:** Employs a full-viewport responsive application shell (`100vw` / `100vh`) with three integrated layout regions:
  1. **Primary Global Rail (Collapsed):** Fixed 56px width with icon-only tool anchors.
  2. **Investigative Workspace:** Fluid 12-column sub-grid supporting dynamic column span (e.g., 3-column incident tree, 6-column graph visualization, 3-column telemetry drawer).
  3. **Collapsible Forensic Drawer:** Contextual slide-out pinned right, variable width (480px default, 720px wide mode) with full vertical height.
- **Gutters & Section Margins:**
  - Panel-to-panel gutters are fixed at `0.75rem` (12px) to maximize screen area for analytics.
  - Workspace exterior viewport margins are locked to `1rem` (16px).
- **Responsive Adaptations:**
  - **Desktop Multi-Pane (>1440px):** Simultaneous visible triage queue, entity graph canvas, and event inspector side-by-side.
  - **Single Monitor / Laptop (1024px - 1439px):** Forensic drawers become absolute slide-overs with scrim overlays; graph toolbars collapse into dropdown groups.
  - **Field Investigation Tablet (<1024px):** Workspace collapses to single-column card flows; global rail collapses into a persistent top app bar.

## Elevation & Depth

Visual hierarchy is maintained through crisp surface separation, tonal borders, and minimal, surgical ambient shadows. Diffuse blurred elevation models are avoided, as they soften edges and impede rapid data parsing.

### Tiered Surface Stacking
1. **Level 0 (Canvas Base - `#F8FAFC`):** The global viewport backdrop behind analytical cards and control headers.
2. **Level 1 (Card & Panel Surface - `#FFFFFF`):** High-clarity primary workspace elements. Surface boundary is established by a 1px border (`#E2E8F0`). Flat elevation; no drop shadow.
3. **Level 2 (Active Inspection / Hover Focus):** Subtle edge reinforcement. Border shifts to `#CBD5E1` accompanied by a micro-shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.06), 0 1px 2px -1px rgba(15, 23, 42, 0.04)`.
4. **Level 3 (Floating Controls & Popovers):** Simulation playback bars, filter dropdown menus, and time-scrub toolbars float above the workspace canvas: `0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.05)`, bordered by `#CBD5E1`.
5. **Level 4 (Forensic Inspection Drawers & Modals):** Pinned high-priority operational surfaces use a deep directional shadow: `0 10px 15px -3px rgba(15, 23, 42, 0.1), 0 4px 6px -4px rgba(15, 23, 42, 0.05)`, anchored with an internal border edge (`border-l border-slate-200`).

### The Ghost Border Philosophy
Surfaces never float without structural definition. Every elevated element—modals, tooltips, cards, slide-over panels—is bound by a 1px neutral hairline border. This guarantees visual edge crispness on high-DPI and standard-gamut command center displays alike.

## Shapes

The design system adopts a calibrated **Soft (`roundedness: 1`)** shape geometry.

- **Baseline Components (Buttons, Inputs, Metric Cells, Badges):** `0.25rem` (4px). Provides subtle structural softening without losing the sharp, geometric authority of enterprise tooling.
- **Content Panels, Data Grids, and Canvas Containers (`rounded-lg`):** `0.5rem` (8px). Encapsulates complex modules without sacrificing internal corner real estate.
- **Large Forensics Drawers, Command Modals (`rounded-xl`):** `0.75rem` (12px). Applied strictly to root modal shells and detached alert overlays.
- **Pill Geometry (Prohibited for Containers):** Completely round pill shapes are reserved exclusively for circular user/node avatars and live status pulse pips (6px × 6px). They are never applied to buttons, filter chips, or input fields.

## Components

### 1. Data Grids & Telemetry Tables
- **Header Cells:** Height 32px, surface `#F1F5F9`, border bottom 1px `#CBD5E1`. Typography: `label-sm`, color `#475569`. Text is uppercase with sorting indicators pinned right.
- **Data Rows:** Compact height 36px (default) or 30px (ultra-dense mode). Surface `#FFFFFF`. Hover state: `#F8FAFC`. Selected state: `#EFF6FF` with a 2px left border accent in `#2563EB`.
- **Cell Padding:** 0 12px (`space-md`). Vertical cell dividers are invisible; horizontal hairlines are 1px `#E2E8F0`.
- **Inline Actions:** Hidden until row hover, pinned in the rightmost cell to prevent visual clutter during vertical scanning.

### 2. Threat Severity Chips & Badges
- **Structure:** Height 20px, inline-flex, items-center, horizontal padding 6px (`space-xs` to `space-sm`), radius 4px.
- **Visual Mapping:**
  - Critical: Background `#FEF2F2`, border 1px `#FCA5A5`, text `#DC2626`.
  - High: Background `#FFF7ED`, border 1px `#FDBA74`, text `#EA580C`.
  - Medium: Background `#FFFBEB`, border 1px `#FCD34D`, text `#D97706`.
  - Low: Background `#ECFDF5`, border 1px `#A7F3D0`, text `#059669`.
  - Info: Background `#F0F9FF`, border 1px `#BAE6FD`, text `#0284C7`.
- **Indicators:** Left-aligned 6px solid status dot or uppercase text tag in `label-sm`.

### 3. Action Buttons & Input Controls
- **Primary Execution Button:** Height 32px, background `#1E3A8A`, text `#FFFFFF`, font `Inter` 12px 600. Hover: `#1E40AF`. Active: `#172554`. Focus ring: 2px `#2563EB` offset 2px.
- **Secondary / Outlined Button:** Height 32px, background `#FFFFFF`, border 1px `#CBD5E1`, text `#0F172A`. Hover: `#F8FAFC`, border `#94A3B8`.
- **Text Inputs & Search Queries:** Height 32px, background `#FFFFFF`, border 1px `#CBD5E1`, font `JetBrains Mono` 12px for query fields, text `#0F172A`. Focus: Border `#2563EB` with 0 0 0 1px `#2563EB`.

### 4. Monospace Telemetry Indicators (IoCs)
- **Visual Treatment:** Inline containers with background `#F1F5F9`, border 1px `#E2E8F0`, radius 3px, padding 1px 5px.
- **Font Stack:** `JetBrains Mono` 11px (`mono-sm`), color `#0F172A`.
- **Interaction:** Hover displays an automatic 1-click clipboard icon; right-click triggers contextual enrichment actions (e.g., "Pivot to VirusTotal", "Filter in Splunk").

### 5. Investigation Timeline & Simulation Control Bar
- **Positioning:** Fixed or floating bottom-docked toolbar.
- **Style:** Surface `#FFFFFF` (95% opacity with 8px backdrop blur), border 1px `#CBD5E1`, elevation Level 3.
- **Controls:** Monospace timestamp scrubber (UTC), discrete micro-steppers for playback (-1x, Pause, Play, +1x, +5x), and severity-coded heat-ticks across the timeline track.

### 6. Interactive Threat Graph Canvas
- **Background:** High-clarity `#F8FAFC` canvas overlaid with an alignment dot matrix (spacing 20px, dot color `#E2E8F0`).
- **Nodes:** Circle radius 18px, fill `#FFFFFF`, border 2px matching node type (Asset: `#1E3A8A`, External IP: `#EA580C`, Process: `#0284C7`).
- **Edges:** SVG bezier connectors 1.5px `#94A3B8`. Selected or active attack paths: 2px solid `#DC2626` with directed directional arrows.

### 7. Collapsible Forensic Inspector Drawer
- **Dimensions:** Pinned right edge, full workspace height, width 480px (resizable up to 800px).
- **Header:** Height 44px, border bottom 1px `#E2E8F0`, flex justify-between with incident ID in `mono-md`, status badge, and close/expand actions.
- **Tabs:** Segmented control tab bar with zero vertical gap, text `label-md`. Panels group entity properties, raw JSON payloads, and timeline history.